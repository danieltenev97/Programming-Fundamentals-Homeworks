﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Weather
{
    class City
    {
        public string citycode { get; set; }
        public double temperatureaverage { get; set; }
        public string weather { get; set; }
    }
}
