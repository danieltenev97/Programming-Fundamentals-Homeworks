﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeamworkProject
{
    class Teams
    {
        public string name { get; set; }
        public string creator { get; set; }
        public List<string> members { get; set; }

       

        

    }
}
