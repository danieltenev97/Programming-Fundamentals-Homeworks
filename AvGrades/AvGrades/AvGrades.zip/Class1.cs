﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AvGrades
{
    class Student
    {

        public string name { get; set; }
        public List<double> grades { get; set; }
        public double average { get; set; }
    }
}
