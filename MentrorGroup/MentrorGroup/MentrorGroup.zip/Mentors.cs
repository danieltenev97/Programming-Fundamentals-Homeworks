﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MentrorGroup
{
    class Mentors
    {
        public string name { get; set; }
        public List<DateTime> date = new List<DateTime>();
        public List<string> comments = new List<string>();

    }
}
