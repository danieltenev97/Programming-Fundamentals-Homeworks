﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentTownGroups
{
    class Group
    {
        public string studentname { get; set; }
        public  DateTime dateregistered = new DateTime();
        public string email { get; set; }
    }
}
