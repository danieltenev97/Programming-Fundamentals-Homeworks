﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesReport
{
    class Sales
    {
       public string town { get; set; }
     public   string product { get; set; }
      public  double price { get; set; }
      public  double quantity { get; set; }


    }
}
